<?php
// This page is used to set the footer details. It was easier putting it on one page on its own instead of copying it to muliple pages 

$footer_msg_old = "<footer><p>&copy; 2018 HybridWebSearch.com</p></footer>";
?>
<html>
     <head>
           <style>     
           footer {
                position: fixed;
                left: 0;
                bottom: 0;
                width: 100%;
                background-color: #ca97e5;
                color: #7d24ad;
                text-align: center;
           }
        </style>
     </head>
<body>
     
     <base href="/">
     
</body>