DROP SCHEMA IF EXISTS hybrid;
CREATE SCHEMA hybrid;
USE hybrid;

CREATE TABLE User_Type(
user_type_id INT NOT NULL AUTO_INCREMENT,	
name ENUM('Customer', 'Company', 'Admin') NOT NULL,
PRIMARY KEY (user_type_id)
);

CREATE TABLE Customer(
customer_id INT NOT NULL AUTO_INCREMENT,
first_name VARCHAR(100) NOT NULL,
last_name VARCHAR(100) NOT NULL,
email VARCHAR(100) NOT NULL,
phone_home VARCHAR(50), /* Not used for calculation, no need to be LONG*/
phone_mobile VARCHAR(50),/* Not used for calculation, not needed to be LONG*/
user_type_id INT DEFAULT '1',
password_enc BLOB NOT NULL,
created_on DATETIME NOT NULL,
ip_address VARCHAR(50),
PRIMARY KEY (customer_id),
FOREIGN KEY (user_type_id) REFERENCES User_Type(user_type_id)
);


CREATE TABLE Company(
company_id INT NOT NULL AUTO_INCREMENT,
name VARCHAR(100) NOT NULL,
address1 VARCHAR(100) NOT NULL,
address2 VARCHAR(100),
city VARCHAR(100) NOT NULL,
eircode VARCHAR(7), /*D01AB23 or D01 AB23*/
rep_first_name VARCHAR(100) NOT NULL,
rep_last_name VARCHAR(100) NOT NULL,
rep_email VARCHAR(100) NOT NULL,
rep_phone VARCHAR(100), /* Not used for calculation, not needed to be LONG*/
user_type_id INT DEFAULT '2',
password_enc BLOB NOT NULL,
created_on DATETIME NOT NULL,
ip_address VARCHAR(50),
PRIMARY KEY (company_id),
FOREIGN KEY (user_type_id) REFERENCES User_Type(user_type_id)
);

CREATE TABLE Admin(
admin_id INT NOT NULL AUTO_INCREMENT,
full_name VARCHAR(100) NOT NULL,
user_type_id INT DEFAULT '3',
login DATETIME NOT NULL,
PRIMARY KEY (admin_id),
FOREIGN KEY (user_type_id) REFERENCES User_Type(user_type_id)
);

INSERT INTO User_Type(user_type_id, name)
VALUES ('1', 'Customer'),('2', 'Company'),('3', 'Admin');


CREATE TABLE Comments (
  cid INT(100) NOT NULL AUTO_INCREMENT,
  uid INT(100) NOT NULL,
  date DATETIME NOT NULL,
  comments VARCHAR(255) NOT NULL,
    ip_add VARCHAR(255) NOT NULL,
  PRIMARY KEY (cid)
);
CREATE TABLE Services (
  sid INT(100) NOT NULL AUTO_INCREMENT,
  title VARCHAR(255) NOT NULL,
  description VARCHAR(255),
  date DATETIME,
  PRIMARY KEY (sid)
);
INSERT INTO Services(sid, title,description,date)
VALUES ('100', 'Free Money', 'We are giving free money', '2006-11-12 12:12:12'),
('101', 'Free blanket', 'We Provide free accomodation and blanket to old people', '2009-01-12 12:12:12');


CREATE TABLE IF NOT EXISTS `Event` (
  `event_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `event_name` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  `event_address1` varchar(255) NOT NULL,
  `event_address2` varchar(255) DEFAULT NULL,
  `event_city` varchar(50) DEFAULT NULL,
  `event_eirocde` varchar(50) DEFAULT NULL,
  `date` date NOT NULL,
  `start_time` datetime NOT NULL,
  `end_time` datetime DEFAULT NULL,
  PRIMARY KEY (`event_id`),
  KEY `company_id` (`company_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;




CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL,
  `uid` varchar(255) NOT NULL,
  `pwd` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `uid`, `pwd`) VALUES
(1, 'admin', '123');

CREATE TABLE if NOT EXISTS `Save_Event` (
  save_event_id int NOT NULL AUTO_INCREMENT,
  event_id int NOT NULL,
  customer_id int NOT NULL,
  company_id int NOT NULL,
  customer_email varchar(100) NOT NULL,
  date datetime NOT NULL,
  status varchar(100) NOT NULL,
  PRIMARY KEY (save_event_id),
  FOREIGN KEY (event_id) REFERENCES Event(event_id),
  FOREIGN KEY (customer_id) REFERENCES Customer(customer_id),
  FOREIGN KEY (company_id) REFERENCES Company(company_id)
);
