<?php
include '../../extras.php';
include "../../connection.php";
    
    if (!($user_type_id == '3')){ //if user is not an admin, it will rediret them.
         header( 'Location: /' );
    }
?>
<!DOCTYPE html>
<html>
     <head>
          <title>Hybrid - Admin Main</title>
          <link rel="stylesheet" href="../../css/style.css">
     </head>

<body>
<!-- Header start -->
<?php echo $header_text;?>
<center>
<div class="bodyContainer"> 
<center>
     <h2>Admin Index</h2>
     <hr/>
     <p>Which type of account would you like to look up?</p>
     <p>&nbsp;</p>
    <p><a href="../../account/admin/company_details.php" class="button">Company</a></p>
    <p><a href="../../account/admin/customer_details.php" class="button">Customer</a></p>
    <p>&nbsp;</p>
    <p>Note: A full list of users' email address is available from your Admin controls.</p>


    
</center>

<p>&nbsp;</p>
<hr/>
<p><a href="/" class="button">Home</a></p>
</div>
</body>
<?php echo $footer_msg ?>
</html>
