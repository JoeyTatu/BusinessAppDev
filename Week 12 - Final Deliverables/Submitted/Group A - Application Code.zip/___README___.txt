hybrid_websearch_raw_code.zip is the raw code taken from Cloud 9.

The Word document named "Cloud9_phpMyAdmin" is instructions on how to open and "Play" (i.e. view) the website from Cloud 9 and view the database by phpMyAdmin (built into Cloud 9).

The MySQL Dump is included if one would like to **import** a Database into the likes of MySQL Workbench
The MySQL Schema is included if one would like to **copy** the code into the likes of MySQL Workbench and run it. 
