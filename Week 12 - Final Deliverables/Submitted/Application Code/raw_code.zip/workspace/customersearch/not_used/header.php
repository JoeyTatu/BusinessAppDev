<?php
include "dbh.php";
?>

<!DOCTYPE html>
<html>
    <head>
        <title>
            
        </title>
                <link rel="stylesheet" type="text/css" href="style.css">

    </head>
    <body>
          <a href="/">Main Index</a>&nbsp;-&nbsp;<a href="../customersearch/index.html">Section Index</a>